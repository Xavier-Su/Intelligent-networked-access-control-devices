/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "oled.h"
#include "ds18b20.h"
#pragma  diag_suppress 870
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
#include <usart.h>
#include <spi.h>
 int temperature=0;
 int signal_switch=0;
 int signal_temp=0;
 int signal_oled=1;//默认0为不存在，1为存在
 void open_door(int signal_switch);
 void get_temp(int signal_temp);
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

// Global Variables for Serial USART1 Receive
unsigned char   	uRx_Data[RECV_MAX] 	;
unsigned char * 	pRx_Data			;
unsigned int 		uLength				;
// unsigned int		recv_flag			;

// Override this function in order to printf via USART1
int __io_putchar(int ch) {
	HAL_UART_Transmit(&huart1, (uint8_t*)&ch, 1, HAL_MAX_DELAY);
	return ch;
}

void dealWithRxBuffer(){
	// When USART1 received something(stored in uRx_Data), interrupt will call this function.
	// for example, you can output what you received via USART1, which will be shown on you computer.
}

uint8_t msg[] = "open";

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();
  MX_USART1_UART_Init();
  MX_I2C1_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
		__HAL_TIM_CLEAR_IT(&htim2,TIM_IT_UPDATE);
	HAL_TIM_Base_Start_IT(&htim2);
	
	
  NRF24L01_Init();
  printf("Setup!\n");
  printf("NRF24L01 2.4G Test Begin\n");

  while (NRF24L01_Check()) {
	  printf("NRF24L01 Module not detected\n");
	  HAL_Delay(1000);
  }
  printf("NRF24L01 Module Start Work\n");
  NRF24L01_TX_Mode();
  printf("Send Data Mode: \n");
	
	signal_oled=oled_check();
	if(signal_oled==1){OLED_Init();OLED_Clear();}
  
	printf("signal_oled:%d\n",signal_oled);
	//if(signal_oled==1){OLED_Clear();}
	//OLED_Clear(); 
	//temperature = DS18B20_Get_Temp();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

		//printf("signal_oled:%d\n",signal_oled);
		if(signal_oled==1){Display1();}
		
		//printf("Send wait......: \n");
		open_door(signal_switch);
		signal_switch=0;
		
		get_temp(signal_temp);
		signal_temp=0;

	  
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
if(GPIO_Pin==GPIO_PIN_0)
{
	signal_switch=1;
	
}
}

void open_door(int signal_switch)
{
	if(signal_switch==0){return;}
	if(signal_switch==1){
	HAL_Delay(10);

	if(HAL_GPIO_ReadPin(GPIOB,button_Pin)==0)
{
		printf("Ready to send\n");
	  uint8_t send_flg = NRF24L01_TxPacket(msg);
	  if (send_flg == TX_OK) {
			
		  printf("Successful sent : %s\n", msg);
			

		  for (int i = 1; i <= 3; i++) {
			  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET);
			  HAL_Delay(100);
			  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_SET);
			  HAL_Delay(100);
			
		  }
			Display2();
	  }
	  else {
		  printf("Send Failed>_< return code: %#x\n", send_flg);
			
		  HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_12);
		  // HAL_Delay(1000);
	  }
}

}
	
}



void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
if(htim2.Instance==TIM2)
{
signal_temp=1;

	
}
}


void get_temp(int signal_temp)
{
	if(signal_temp==0){return;}
	if(signal_temp==1){
	
temperature = DS18B20_Get_Temp();
		if(temperature < 0)
			printf("现在温度? -%d ℃\r\n",temperature/10);
		else
			printf("现在温度? %d ℃\r\n",temperature/10);
		temperature=(temperature/10)-1;
		//DispalyChinese2();
}
	}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
