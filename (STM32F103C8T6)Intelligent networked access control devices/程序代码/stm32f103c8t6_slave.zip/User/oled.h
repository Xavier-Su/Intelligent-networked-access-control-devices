#ifndef OLED_H__
#define OLED_H__

#include "stm32f1xx_hal.h"
void WriteCmd(void);
void OLED_WR_CMD(uint8_t cmd);
void OLED_WR_DATA(uint8_t data);
void OLED_Init(void);
void OLED_Clear(void);
void OLED_Display_On(void);
void OLED_Display_Off(void);
void OLED_Set_Pos(uint8_t x, uint8_t y) ;
void OLED_On(void)  ;
unsigned int oled_pow(uint8_t m,uint8_t n);
void OLED_ShowNum(uint8_t x,uint8_t y,unsigned int num,uint8_t len,uint8_t size2);
void OLED_ShowChar(uint8_t x,uint8_t y,uint8_t chr,uint8_t Char_Size);
void OLED_ShowString(uint8_t x,uint8_t y,uint8_t *chr,uint8_t Char_Size);
void OLED_ShowCHinese1(uint8_t x,uint8_t y,uint8_t no);
void OLED_ShowCHinese2(uint8_t x,uint8_t y,uint8_t no);
void DispalyChinese1(void);
void DispalyChinese2(void);
void DispalyChinese3(void);
void DispalyChinese4(void);
void Display1(void);
void Display2(void);
int oled_check(void);

#endif
