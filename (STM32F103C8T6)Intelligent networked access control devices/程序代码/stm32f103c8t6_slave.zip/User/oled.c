#include "oled.h"
#include "i2c.h"
#include "oledfont.h"
#include "stdio.h"

extern int temperature;
extern int signal_oled;

//初始化命令
uint8_t CMD_Data[]={
0xAE, 0x00, 0x10, 0x40, 0xB0, 0x81, 0xFF, 0xA1, 0xA6, 0xA8, 0x3F,
					
0xC8, 0xD3, 0x00, 0xD5, 0x80, 0xD8, 0x05, 0xD9, 0xF1, 0xDA, 0x12,
					
0xD8, 0x30, 0x8D, 0x14, 0xAF};
void WriteCmd()
{

	uint8_t i = 0;
	for(i=0; i<27; i++){
		HAL_I2C_Mem_Write(&hi2c1 ,0x78,0x00,I2C_MEMADD_SIZE_8BIT,CMD_Data+i,1,0x100);
		
	}
}

int oled_check()
{

	uint8_t i = 0;
	for(i=0; i<27; i++){
		//HAL_I2C_Mem_Write(&hi2c1 ,0x78,0x00,I2C_MEMADD_SIZE_8BIT,CMD_Data+i,1,0x100);
		if(HAL_I2C_Mem_Write(&hi2c1 ,0x78,0x00,I2C_MEMADD_SIZE_8BIT,CMD_Data+i,1,0x100)==HAL_BUSY){printf("busybusy,\n");if(i>5){signal_oled=0;}}
	}
	return signal_oled;
}

//向设备写控制命令
void OLED_WR_CMD(uint8_t cmd)
{
	HAL_I2C_Mem_Write(&hi2c1 ,0x78,0x00,I2C_MEMADD_SIZE_8BIT,&cmd,1,0x100);
	
}
//向设备写数据
void OLED_WR_DATA(uint8_t data)
{

	HAL_I2C_Mem_Write(&hi2c1 ,0x78,0x40,I2C_MEMADD_SIZE_8BIT,&data,1,0x100);
}
//初始化oled屏幕
void OLED_Init(void)
{ 	
	HAL_Delay(200);
 
	WriteCmd();
}
//清屏
void OLED_Clear()
{
	
	uint8_t i,n;		    
	for(i=0;i<8;i++)  
	{  
		OLED_WR_CMD(0xb0+i);
		OLED_WR_CMD (0x00); 
		OLED_WR_CMD (0x10); 
		for(n=0;n<128;n++)
			OLED_WR_DATA(0);
	} 
}
//开启OLED显示
void OLED_Display_On(void)
{
	OLED_WR_CMD(0X8D);  //SET DCDC命令
	OLED_WR_CMD(0X14);  //DCDC ON
	OLED_WR_CMD(0XAF);  //DISPLAY ON
}
//关闭OLED显示    
void OLED_Display_Off(void)
{
	OLED_WR_CMD(0X8D);  //SET DCDC命令
	OLED_WR_CMD(0X10);  //DCDC OFF
	OLED_WR_CMD(0XAE);  //DISPLAY OFF
}		   			 
void OLED_Set_Pos(uint8_t x, uint8_t y) 
{ 	
	OLED_WR_CMD(0xb0+y);
	OLED_WR_CMD(((x&0xf0)>>4)|0x10);
	OLED_WR_CMD(x&0x0f);
} 
 
void OLED_On(void)  
{  
	uint8_t i,n;		    
	for(i=0;i<8;i++)  
	{  
		OLED_WR_CMD(0xb0+i);    //设置页地址(0~7)
		OLED_WR_CMD(0x00);      //设置显示地址·-列低地址·
		OLED_WR_CMD(0x10);      //设置显示地址·-列高地址·
		for(n=0;n<128;n++)
			OLED_WR_DATA(1); 
	} //¸更新显示
}
unsigned int oled_pow(uint8_t m,uint8_t n)
{
	unsigned int result=1;	 
	while(n--)result*=m;    
	return result;
}

// Parameters     : x0,y0 -- 起始点坐标(x0:0~127, y0:0~7); x1,y1 -- 起点对角线(结束点)的坐标(x1:1~128,y1:1~8)
// Description    : 显示BMP位图
void OLED_DrawBMP(unsigned char x0,unsigned char y0,unsigned char x1,unsigned char y1,unsigned char BMP[])
{
    unsigned int j=0;
    unsigned char x,y;

  if(y1%8==0)
        y = y1/8;
  else
        y = y1/8 + 1;
    for(y=y0;y<y1;y++)
    {
			
        OLED_Set_Pos(x0,y);
    for(x=x0;x<x1;x++)
        {
            OLED_WR_DATA(BMP[j++]);
        }
    }
}

//显示两个数字
//x,y :起点坐标
//len :数字的位数
//size:字体大小
//mode:模式	0,填充;1,叠加
//num:数值(0~4294967295);	 		  
void OLED_ShowNum(uint8_t x,uint8_t y,unsigned int num,uint8_t len,uint8_t size2)
{         	
	uint8_t t,temp;
	uint8_t enshow=0;						   
	for(t=0;t<len;t++)
	{
		temp=(num/oled_pow(10,len-t-1))%10;
		if(enshow==0&&t<(len-1))
		{
			if(temp==0)
			{
				OLED_ShowChar(x+(size2/2)*t,y,' ',size2);
				continue;
			}else enshow=1; 
		 	 
		}
	 	OLED_ShowChar(x+(size2/2)*t,y,temp+'0',size2); 
	}
} 
//在指定位置显示一个字符¸包括部分字符
//x:0~127
//y:0~63
//mode:0,反白显示;1,正常显示
//size:选择字体：16/12 
void OLED_ShowChar(uint8_t x,uint8_t y,uint8_t chr,uint8_t Char_Size)
{      	
	unsigned char c=0,i=0;	
		c=chr-' ';//得到偏移后的值
		if(x>128-1){x=0;y=y+2;}
		if(Char_Size ==16)
			{
			OLED_Set_Pos(x,y);	
			for(i=0;i<8;i++)
			OLED_WR_DATA(F8X16[c*16+i]);
			OLED_Set_Pos(x,y+1);
			for(i=0;i<8;i++)
			OLED_WR_DATA(F8X16[c*16+i+8]);
			}
			else {	
				OLED_Set_Pos(x,y);
				for(i=0;i<6;i++)
				OLED_WR_DATA(F6x8[c][i]);
				
			}
}
 
//显示字符串
void OLED_ShowString(uint8_t x,uint8_t y,uint8_t *chr,uint8_t Char_Size)
{
	unsigned char j=0;
	while (chr[j]!='\0')
	{		OLED_ShowChar(x,y,chr[j],Char_Size);
			x+=8;
		if(x>120){x=0;y+=2;}
			j++;
	}
}


//显示汉字
//hzk 用取模软件得出的数组

void OLED_ShowCHinese0(uint8_t x,uint8_t y,uint8_t no)
{      			    
	uint8_t t,adder=0;
	OLED_Set_Pos(x,y);	
    for(t=0;t<16;t++)
		{
				OLED_WR_DATA(Hzk3[2*no][t]);
				adder+=1;
     }	
		OLED_Set_Pos(x,y+1);	
    for(t=0;t<16;t++)
			{	
				OLED_WR_DATA(Hzk3[2*no+1][t]);
				adder+=1;
      }					
}


void OLED_ShowCHinese1(uint8_t x,uint8_t y,uint8_t no)
{      			    
	uint8_t t,adder=0;
	OLED_Set_Pos(x,y);	
    for(t=0;t<16;t++)
		{
				OLED_WR_DATA(Hzk1[2*no][t]);
				adder+=1;
     }	
		OLED_Set_Pos(x,y+1);	
    for(t=0;t<16;t++)
			{	
				OLED_WR_DATA(Hzk1[2*no+1][t]);
				adder+=1;
      }					
}
void OLED_ShowCHinese2(uint8_t x,uint8_t y,uint8_t no)
{      			    
	uint8_t t,adder=0;
	OLED_Set_Pos(x,y);	
    for(t=0;t<16;t++)
		{
				OLED_WR_DATA(Hzk2[2*no][t]);
				adder+=1;
     }	
		OLED_Set_Pos(x,y+1);	
    for(t=0;t<16;t++)
			{	
				OLED_WR_DATA(Hzk2[2*no+1][t]);
				adder+=1;
      }					
}

void OLED_ShowCHinese3(uint8_t x,uint8_t y,uint8_t no)
{      			    
	uint8_t t,adder=0;
	OLED_Set_Pos(x,y);	
    for(t=0;t<16;t++)
		{
				OLED_WR_DATA(Hzk[2*no][t]);
				adder+=1;
     }	
		OLED_Set_Pos(x,y+1);	
    for(t=0;t<16;t++)
			{	
				OLED_WR_DATA(Hzk[2*no+1][t]);
				adder+=1;
      }					
}
void OLED_ShowCHinese4(uint8_t x,uint8_t y,uint8_t no)
{      			    
	uint8_t t,adder=0;
	OLED_Set_Pos(x,y);	
    for(t=0;t<16;t++)
		{
				OLED_WR_DATA(Hzk4[2*no][t]);
				adder+=1;
     }	
		OLED_Set_Pos(x,y+1);	
    for(t=0;t<16;t++)
			{	
				OLED_WR_DATA(Hzk4[2*no+1][t]);
				adder+=1;
      }					
}

void DispalyChinese0(void)
{
	  OLED_ShowCHinese0(16,0,0);
		OLED_ShowCHinese0(32,0,1);
	  OLED_ShowCHinese0(48,0,2);
		OLED_ShowCHinese0(64,0,3);
		OLED_ShowCHinese0(80,0,4);
		OLED_ShowCHinese0(96,0,5);
		
}

void DispalyChinese1(void)
{
		OLED_ShowCHinese1(0,2,0);
		OLED_ShowCHinese1(16,2,1);
		OLED_ShowCHinese1(32,2,2);
		OLED_ShowCHinese1(48,2,3);
		OLED_ShowCHinese1(64,2,4);
		OLED_ShowCHinese1(80,2,5);
		OLED_ShowCHinese1(96,2,6);
		OLED_ShowCHinese1(112,2,7);
}
void DispalyChinese2(void)
{
	  OLED_ShowCHinese2(32,4,0);
		OLED_ShowCHinese2(48,4,1);
		OLED_ShowNum(64,4,temperature,2,16);
		OLED_ShowCHinese2(80,4,2);
		
}

void DispalyChinese3(void)
{
	  OLED_ShowCHinese3(16,6,0);
		OLED_ShowCHinese3(32,6,1);
	  OLED_ShowCHinese3(48,6,2);
		OLED_ShowCHinese3(64,6,3);
		OLED_ShowCHinese3(80,6,4);
		OLED_ShowCHinese3(96,6,5);
		
}

void DispalyChinese4(void)
{
		OLED_Clear();
	  OLED_ShowCHinese4(0,2,0);
		OLED_ShowCHinese4(16,2,1);
		OLED_ShowCHinese4(32,2,2);
		OLED_ShowCHinese4(48,2,3);
		OLED_ShowCHinese4(64,2,4);
		OLED_ShowCHinese4(80,2,5);
		OLED_ShowCHinese4(96,2,6);
		OLED_ShowCHinese4(112,2,7);

		
}

void Display1(void)
{
	DispalyChinese0();
	DispalyChinese1();
	DispalyChinese2();
	DispalyChinese3();
	
}
void Display2(void)
{
	OLED_Clear();
	OLED_DrawBMP(0,0,128,7,BMP2);
	HAL_Delay(300);
	OLED_DrawBMP(0,0,128,7,BMP1);
	HAL_Delay(800);
}

